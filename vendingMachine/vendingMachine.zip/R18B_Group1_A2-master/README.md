# Vending Machine Application: Group 1

### Introduction
This module contains a Vending Machine application that allows customers to purchase products while other users (sellers, cashiers, and owners) maintain the machine.
JUnit testing for this application can also be found in this module, with a code coverage of over 75%.

### Usage: Running this Program
To run this application in command-line:
  1. Navigate to the project's directory:  
   ` $ cd ./R18B_Group1_A2 `
  2. Run: 
   ` $  gradle run -q --console=plain `

You will then be guided with instructions on how to proceed. 
***Note that all commands in this program are case-insensitive EXCEPT for usernames and passwords.***


### Testing
To run the tests associated with this application:
  1. Navigate to the project folder: 
   ` $ cd ./R18B_Group1_A2 `
  2. Run: 
   ` $ gradle clean build `

This will automatically run all the tests and produce reports detailing the results.
Different versions of the test reports are stored. 

JUnit test reports can be found by:
  1. Navigating to the tests folder: 
   ` $ cd ./R18B_Group1_A2/build/reports/tests/test `
  2. Run: 
   - ` $ open index.html ` for macOS
   - ` xdg-open index.html ` for Linux
   - ` index.html ` for Windows
 
 JaCoCo test reports offer a detailed breakdown, found by:
   1. Navigating to the html folder: 
   ` $ cd ./R18B_Group1_A2/build/reports/tests/jacoco/test/html `
  2. Run: 
   - ` $ open index.html ` for macOS
   - ` xdg-open index.html ` for Linux
   - ` index.html ` for Windows

Jenkins offers concise test coverage reports, found by opening Jenkins with Ngrok link and clicking on the most recent repository addition.
