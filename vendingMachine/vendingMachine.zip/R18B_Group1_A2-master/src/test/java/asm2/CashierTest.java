package asm2;
import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class CashierTest {
    String db_path = "src/main/java/asm2/Machine_change.txt";
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

    @Test
    void testHelp() {
        String data = "h\nhelp"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        new Cashier().help();
        System.setIn(stdin);
        Assert.assertEquals("COMMANDDESCRIPTIONREPORTDisplayareportofeitherr1thelatestnotecoinquantitiesinthemachineORr2alltransactionsdenomdeltaChangeanotecoindenominationsquantitybydeltaamountegUPD0101HELPDisplaysavailablecashiercommandsSAVECommitanynotecoinquantityupdatesandexittheprogramOUTExittheprogramwithoutcommittinganychangesNOTECommandsarecaseinsensitivePleasewritecoinsindecimalformeg010050andnotesasintegervalueseg5",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", "").replace(" ", ""));
    }

    @Test
    void testReport2() {
        Cashier c = new Cashier();
        assertDoesNotThrow(() -> c.display_r2());
    }

    @Test
    void testArgs() { // test invalid argument cases
        Cashier test = new Cashier();
        String[] test_1 = {"0.10", "ten"};
        assertFalse(test.valid_update(test_1));

        String[] test_2 = {"0.1", "-10000"};
        assertFalse(test.valid_update(test_2));

        String[] test_3 = {"ten", "1"};
        assertFalse(test.valid_update(test_3));

        String[] test_4 = {"0.1", "1"}; // must be '0.10' as show in display
        assertFalse(test.valid_update(test_4));

        String[] test_5 = {" ", "1"};
        assertFalse(test.valid_update(test_5));

        String[] test_6 = {"", "1"};
        assertFalse(test.valid_update(test_6));

        String[] test_7 = {"5", ""};
        assertFalse(test.valid_update(test_7));

        String[] test_8 = {"0.10", "1", "2"};
        assertFalse(test.valid_update(test_8));

        String[] test_9 = {"0.10"};
        assertFalse(test.valid_update(test_9));

        String[] test_10 = {""};
        assertFalse(test.valid_update(test_10));

        String[] test_11 = {"a"};
        assertFalse(test.valid_update(test_11));

        String[] test_12 = {"c c"};
        assertFalse(test.valid_update(test_12));
    }
    @Test
    void testQuantUpdate() {
        Cashier test = new Cashier();
        test.reset_machine();
        test.save_changes();
        test.modify_quant("0.10", 1);
        test.save_changes();
        try {
            File f = new File(db_path);
            String s = "";
            Scanner scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            assertEquals("0.10, 1", s);
            scan.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
        assertEquals("INVALID", test.modify_quant("0.10", -2));
        test.save_changes();
        try {
            File f = new File(db_path);
            String s = "";
            Scanner scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            assertEquals("0.10, 1", s);
            scan.close();
            assertEquals("SUCCESS", test.modify_quant("0.10", -1));
            test.save_changes();
            scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            assertEquals("0.10, 0", s);
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
    }

    @Test
    void testReset() {
        new Cashier().reset_machine();
        new Cashier().save_changes();
        assertEquals(0.0, new Cashier().get_total_machine_money());
        for (int i = 0; i < Cashier.accepted_notes_and_coins.length; i++) {
            String type = Cashier.accepted_notes_and_coins[i];
            String[] test_input = {String.format("%s", type), "100"};
            assertTrue(new Cashier().valid_update(test_input));
            new Cashier().modify_quant(type, 100);
            assertEquals(new Cashier().get_quant(type), 0);
        }
        new Cashier().display_r1();
        new Cashier().save_changes();
        new Cashier().display_r1();
        new Cashier().init_map();
        for (int i = 0; i < Cashier.accepted_notes_and_coins.length; i++) {
            String type = Cashier.accepted_notes_and_coins[i];
            assertEquals(new Cashier().get_quant(type), 100);
        }
        assertEquals(18880.0, new Cashier().get_total_machine_money());
        new Cashier().reset_machine();
        new Cashier().save_changes();
        for (int i = 0; i < Cashier.accepted_notes_and_coins.length; i++) {
            String type = Cashier.accepted_notes_and_coins[i];
            assertEquals(new Cashier().get_quant(type), 0);
        }
        try {
            File f = new File(db_path);
            String s = "";
            Scanner scan = new Scanner(f);
            scan = new Scanner(f);
            Integer i = 0;
            String[] types = Cashier.accepted_notes_and_coins;
            scan.nextLine();
            while(scan.hasNextLine()){
                s = scan.nextLine();
                String expected_line = String.format("%s, %d", types[i], 0);
                assertEquals(expected_line, s);
                i++;
            }
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
    }
    @Test
    void testCashierWithGUI() {
        String data = "0.10 1\nsave"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        new AppUI().cashierTransaction();
        System.setIn(stdin);
        try {
            File f = new File(db_path);
            String s = "";
            Scanner scan = new Scanner(f);
            scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            String expected_line = String.format("0.10, 1");
            assertEquals(expected_line, s);
            new Cashier().reset_machine();
            new Cashier().save_changes();
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
    }
    @Test
    void testCashierWithGUI1() {
        String data = "wrongcommand\n0.10 -100\n0.10 1\nsave"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        new AppUI().cashierTransaction();
        System.setIn(stdin);
        try {
            File f = new File(db_path);
            String s = "";
            Scanner scan = new Scanner(f);
            scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            String expected_line = String.format("0.10, 1");
            assertEquals(expected_line, s);
            new Cashier().reset_machine();
            new Cashier().save_changes();
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
    }
}