package asm2;

import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Scanner;
public class AppUITest{
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }



    @Test
    void testSellerWithGUI1() {
        String data = "wrongcommand\nMODIFY\nwrongcommnad\nQUANTITY\nwrongcomamand\n4000\n20\n-10\n8\nout\n"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        AppUI test = new AppUI();
        test.sellerTransaction();
        System.setIn(stdin);
    }

    @Test
    public void testChangeQuantity() {

        String data = "4000\n7"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("QUANTITY"));
        System.setIn(stdin);
    }

    @Test
    public void testInvalidProduct() {
        String data = "1\n1000\n7"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        assertEquals("SUCCESS", new AppUI().modifyWhat("QUANTITY"));
        System.setIn(stdin);
    }

    @Test
    public void testInvalidQty() {
        String data = "1000\n25\n7"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        assertEquals("SUCCESS", new AppUI().modifyWhat("QUANTITY"));
    }
  
  @Test
    public void testInvalidQty2() {
        String data = "4000\n1\nsave\nout"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        AppUI test = new AppUI();
        assertEquals("SUCCESS", test.modifyWhat("QUANTITY"));
        System.setIn(stdin);
    }

    @Test
    public void testReportCall() {
        AppUI test = new AppUI();
        String invInp = test.callReport("invalidreport");
        Assert.assertEquals("Incorrect input Please type either R1 or R2",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        assertEquals("INVALID", invInp);
        assertEquals("SUCCESS", test.callReport("R1"));
        assertEquals("SUCCESS", test.callReport("R2"));
    }

    @Test
    void testSellerGeneratesReport1() {
        String data = "REPORT\nwrongcommnad\nR1\nout\n"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        AppUI test = new AppUI();
        test.sellerTransaction();
        System.setIn(stdin);
    }

    @Test
    void testSellerGeneratesReport2() {
        String data = "REPORT\nR2\nout\n"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        AppUI test = new AppUI();
        test.sellerTransaction();
        System.setIn(stdin);
    }

    @Test
    public void testOwnerReportCall() {
        AppUI test = new AppUI();
        String invInp = test.callReport("invalidreport");
        Assert.assertEquals("Incorrect input Please type either R1 or R2",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        assertEquals("INVALID", invInp);
        assertEquals("SUCCESS", test.callOwnerReport("R1"));
        assertEquals("SUCCESS", test.callOwnerReport("R2"));
    }


    @Test
    public void testChangeCategory() {
        String data = "fakeproduct\n4004\nnoncategory\nCandies"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("CATEGORY"));
        System.setIn(stdin);
    }

    @Test
    public void testChangeCategory2() {
        String data = "4004\nCandies"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("CATEGORY"));
        System.setIn(stdin);
    }

    @Test
    public void testChangePrice() {
        String data = "fakeproduct\n4004\ncat\n0.50"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("PRICE"));
        System.setIn(stdin);
    }

    @Test
    public void testChangeNameFail() {
        String data = "fakeproduct\n4004\nSour Patch\nq"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("NAME"));
        System.setIn(stdin);
    }

    @Test
    public void testChangeCodeFail() {
        String data = "fakeproduct\n4004\ncat\n4004"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SUCCESS", new AppUI().modifyWhat("CODE"));
        System.setIn(stdin);
    }


}
