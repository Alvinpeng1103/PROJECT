package asm2;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class RegisterTest {

    @Test
    public void testRead(){
        String[] r1 = Register.read("john");


        assertEquals("Charles", r1[0]);

        assertEquals("40691", r1[1]);


        String[] r2 = Register.read("alvin");

        assertNull(r2[0]);

        assertNull(r2[1]);

    }

    @Test
    public void testCheck(){
        assertTrue(Register.check("john"));
        assertFalse(Register.check("alvin"));
    }

    @Test
    public void testWrite(){
        assertDoesNotThrow(() -> Register.write("john", "Charles", "40691"));
    }

    //Remember delete new line in register.txt after doing this test

}
