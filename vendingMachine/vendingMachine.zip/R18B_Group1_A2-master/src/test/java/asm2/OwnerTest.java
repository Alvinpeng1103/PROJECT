package asm2;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class OwnerTest {

    @Test
    public void testValidAddUser() {
        String data = "heather\nseller\nseller"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        Owner test = new Owner();
        Assert.assertEquals("SUCCESS", test.addUser());
        System.setIn(stdin);
    }

    @Test
    public void testFailAddUser() {
        String data = "nonexistentuser\nfakerole"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        Owner test = new Owner();
        Assert.assertEquals("FAIL", test.addUser());
        System.setIn(stdin);
    }


    @Test
    public void testFailRemoveNonexistent() {
        String data = "nonexistentuser\nfakerole"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        Owner test = new Owner();
        Assert.assertEquals("FAIL", test.removeUser());
        System.setIn(stdin);
    }

    @Test
    public void testFailRemoveCustomer() {
        String data = "john\ncustomer"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        Owner test = new Owner();
        Assert.assertEquals("FAIL", test.removeUser());
        System.setIn(stdin);
    }

    @Test
    public void tempSignUpUser(){
        String signUpdata = "removeTester\nabcd\nabcd";
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(signUpdata.getBytes()));
        String test = new App().signUp("SELLER");
        System.setIn(stdin);
        assertEquals("SIGNED UP AND LOGGED IN", test);
    }

    @Test
    public void testRemoveCustomer() {
        String data = "removeTester\nseller"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        Owner test = new Owner();
        Assert.assertEquals("SUCCESS", test.removeUser());
        System.setIn(stdin);
    }
}
