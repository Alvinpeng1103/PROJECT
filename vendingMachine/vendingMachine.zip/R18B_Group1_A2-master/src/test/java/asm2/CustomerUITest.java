package asm2;

import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CustomerUITest {
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

    @Test
    public void testTimeOut() {
        CustomerUI test = new CustomerUI();
        test.setTimerWait(5); // instead of testing idle timeout of 2 minutes test just 5 seconds
        long start = System.currentTimeMillis();
        Assert.assertEquals("", test.getCustomerInput());
        long end = System.currentTimeMillis();
        assertTrue((end - start) >= (5 * 1000) && (end - start) < (6 * 1000));
    }

    @Test
    public void testCustomerSelectsItemCancels() {
        String data = "Done\nCancel"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        new CustomerUI(false).customerCalls("1001 1");
        System.setIn(stdin);

        Assert.assertEquals("Select a product by entering its code and the quantity you want Eg 1001 3 Type CANCEL to quit DONE to checkout DISP to see menu CHECKOUT COMMENCINGWould you like to pay with CASH or CARD You may still CANCEL Order was cancelled Bye",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }

    @Test
    public void testCustomerBuysItemCard() {

        String data = "Done\nCard\nKate\n1\nCharles\n40691"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        new CustomerUI(false).customerCalls("1001 1");
        System.setIn(stdin);
    }

    @Test
    public void testCustomerCancels() {

        String data = "Cancel"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        new CustomerUI(false).customerCalls("1001 1");
        System.setIn(stdin);

        Assert.assertEquals("Select a product by entering its code and the quantity you want Eg 1001 3 Type CANCEL to quit DONE to checkout DISP to see menu " +
                        "Order was cancelled Bye",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }

    @Test
    public void invalidCmd() {
        String data = "invalidcmd\nCancel"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));

        new CustomerUI(false).customerCalls("invalidcmd");
        System.setIn(stdin);

        Assert.assertEquals("Select a product by entering its code and the quantity you want Eg 1001 3 Type CANCEL to quit DONE to checkout DISP to see menu " +
                        "INCORRECT COMMAND please read instructions and try again" +
                "Select a product by entering its code and the quantity you want Eg 1001 3 Type CANCEL to quit DONE to checkout DISP to see menu " +
                        "Order was cancelled Bye",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }
}
