package asm2;

import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;

public class SellerTest {
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

    @Test
    public void TestaddInstructions(){
        Seller s = new Seller();
        s.addInstruction("CP", "chanage the price");
        assertDoesNotThrow(() -> s.addInstruction("CP", "chanage the price"));
    }

    @Test
    public void TestselectProducts(){
        Seller s = new Seller();
        s.changeQ("1001", "7");
        String[] x = s.selectProduct("1001");
        assertEquals("Drinks",x[0]);


        assertNull(s.selectProduct("120000000"));

    }

    @Test
    public void TestdisplayProducts(){
        Seller s = new Seller();
        String x = s.displayProduct("1001");
        assertEquals("SUCCESS", x);
        assertEquals("INVALID", s.displayProduct("1200"));
    }

    @Test
    public void TestdisplayIns(){
        Seller s = new Seller();
        assertDoesNotThrow(() -> s.displayInstructions());

    }

    @Test
    public void TestchangeQ(){
        Seller s = new Seller();

        s.changeQ("0000", "8");

        String[] y = s.selectProduct("0000");
        assertEquals("8", y[4]);

        s.changeQ("0000", "7");

        String[] z = s.selectProduct("0000");

        assertEquals("7", z[4]);

    }

    @Test
    public void TestchangeP(){
        Seller s = new Seller();

        s.changeP("0000", "3.00");

        String[] y = s.selectProduct("0000");

        assertEquals("3.00", y[3]);


        s.changeP("0000", "2.50");

        String[] z = s.selectProduct("0000");

        assertEquals("2.50", z[3]);

    }

    @Test
    public void TestchangeC(){
        Seller s = new Seller();

        s.changeC("1001", "Drinks");

        String[] y = s.selectProduct("1001");

        assertEquals("Drinks", y[0]);


    }

    @Test
    public void TestchangeN(){
        Seller s = new Seller();

        s.changeN("1001", "Coca cola");

        String[] y = s.selectProduct("1001");

        assertEquals("Coca cola", y[2]);



    }

    @Test
    public void TestchangeCode(){
        Seller s = new Seller();

        // set the values
        s.changeCode("0000", "5000");

        // Test the values
        String[] y = s.selectProduct("5000");
        assertEquals("5000", y[1]);


        s.changeCode("5000", "0000");

        String[] z = s.selectProduct("0000");
        assertEquals("0000", z[1]);

    }



    @Test
    public void testSellerReportError(){
        Seller s = new Seller();
        assertDoesNotThrow(() -> s.generateReport1());
    }

    @Test
    public void testCheckCode(){
        Seller s = new Seller();
        assertTrue(s.checkCode("0000"));
        assertFalse(s.checkCode("9999999999999999999999999"));
    }

    @Test
    public void testCheckName(){
        Seller s = new Seller();
        assertTrue(s.checkName("Mineral Water"));
        assertFalse(s.checkName("cpen2847"));
    }






}
