package asm2;
import org.junit.After;
import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {
    String db_file = "src/main/java/asm2/logindbtest.txt";
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }


    @Test
    public void test_sign_matching_pass(){
        String pass1 = "pass";
        String pass2 = "pass2";
        assertFalse(new Login().passMatching(pass1, pass2));
        Assert.assertEquals("PasswordsnotmatchingReenterthepasswordagain",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9]", ""));
        pass2 = "pass";
        assertTrue(new Login().passMatching(pass1, pass2));
    }
    @Test
    public void test_sign_up(){
        Login test = new Login(db_file);
        File file = new File(db_file);
        try {
            file.createNewFile();
        }
        catch (IOException e) {
            System.err.println("Failed to create file");
        }
        String user = "soft2412";
        String pass = "softr18b1";
        assertEquals("\nSuccessfully signed up. Logging in with your new account...",
                test.signUpUser(user, pass, "CUSTOMER"));
        // test cannot sign up with an existing username
        assertTrue(test.usernameTaken(user, "CUSTOMER"));
        if(file.delete()) {
            System.out.println("File deleted successfully");
        }
        else {
            System.out.println("Failed to delete the file");
        }
    }
    @Test
    public void testAppCust_SignUp() {
        // test signing up with username soft and password soft
        String data = "john\nsoft\nsoft\nsoft"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SIGNED UP AND LOGGED IN", new App().customerAccess("SIGN UP"));
        System.setIn(stdin); // reset input stream
        try {
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/logindb.txt", "rw");
            // remove change by deleting the last line
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }
    @Test
    public void testAppAlt_SignUp() {
        // test signing up with username soft and password soft
        String data = "john\nsoft\nsoft\nwrongpassword\nsoft"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("SIGNED UP AND LOGGED IN", new App().altAccess("SIGN UP", "CUSTOMER"));
        System.setIn(stdin); // reset input stream
        try {
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/logindb.txt", "rw");
            // remove change by deleting the last line
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }
    @Test
    public void testAlt_Login1(){
        String data = "john\npotato"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("LOGGED IN", new App().altAccess("LOG IN", "CUSTOMER"));
        System.setIn(stdin); // reset input stream
        Assert.assertEquals("Enter your username Enter Your desired password Logged in",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }
    @Test
    public void testCust_Login1(){
        String data = "john\npotato"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("LOGGED IN", new App().customerAccess("LOG IN"));
        System.setIn(stdin);
        Assert.assertEquals("Enter your username Enter Your desired password Logged in",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }
    @Test
    public void testAltLogin2(){
        String data = "john\nwrongpassword"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("INVALID", new App().altAccess("LOG IN", "SELLER"));
        System.setIn(stdin);
        Assert.assertEquals("Enter your username Enter Your desired password This password does not match the usernameAccount does not exist",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }
    @Test
    public void testCustLogin2(){
        String data = "john\nwrongpassword"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("INVALID", new App().customerAccess("LOG IN"));
        System.setIn(stdin);

        Assert.assertEquals("Enter your username Enter Your desired password This password does not match the usernameAccount does not exist",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));

    }
    @Test
    public void testAltLogin3(){
        String data = "nonexistentusername\nwrongpassword"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("INVALID", new App().altAccess("LOG IN", "CASHIER"));
        System.setIn(stdin);
        Assert.assertEquals("Enter your username Enter Your desired password Account does not exist",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }
    @Test
    public void testCust_Login3(){
        String data = "nonexistentusername\nwrongpassword"; // standard input to be passed
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        assertEquals("INVALID", new App().customerAccess("LOG IN"));
        System.setIn(stdin);
        Assert.assertEquals("Enter your username Enter Your desired password Account does not exist",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
    }


    @Test
    void testAddToCart() {
        PasswordField test = new PasswordField();

        // check that function doesn't throw error
        assertDoesNotThrow(() -> test.readPassword("Enter"));
    }
}
