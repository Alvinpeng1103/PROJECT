package asm2;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class CustomerTest {
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

    @AfterAll
    static void revertChange(){
        try {
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/order_history.txt", "rw");
            // remove change by deleting the last line
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }


    @Test
    void testMenuPrinted(){
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // check that function can open file
        assertDoesNotThrow(test::displayProducts);

    }

    @Test
    void testAddToCart(){
        Customer test = new Customer();

        // check that function can open file
        assertDoesNotThrow( () -> test.selectProducts("1000", "1"));
        test.cancelOrder("user cancelled");  // clear cart after test

        // valid input
        String item = "Sprite";
        Double price = 3.00;
        String qty = "1";

        // simulate what the cart should look like
        List<String> dummyCart = new ArrayList<>();
        dummyCart.add(item);

        // check that item is added to cart
        assertEquals(dummyCart, test.addToCart(item, price, qty) );
    }


    @Test
    void testInvalidProductQty() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // order is too large
        test.selectProducts("1000", "20");

        Assert.assertEquals("There isnt enough of this item in stock please order a lower quantity",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        test.cancelOrder("user cancelled");
    }

    @Test
    void testValidOrder() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // valid input
        test.selectProducts("1000", "1");
        Assert.assertEquals("ITEM ADDED TO CARTYour cart currently contains 1x SpriteTotal 30",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));

        Assert.assertEquals("SUCCESS", test.checkoutCart());

        // ERASE THE ENTRY FROM THIS TEST IN ORDER HISTORY FILE
        try{
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/order_history.txt", "rw");
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }

    @Test
    void testOrderFakeProduct() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // item doesn't exist
        test.selectProducts("123", "1");
        Assert.assertEquals("The product code you entered doesnt exist Please try again",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));

        test.cancelOrder("user cancelled");
    }

    @Test
    void testInvalidQty() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // "quantity" is not a number
        test.selectProducts("1000", "cat");
        Assert.assertEquals("INVALID COMMANDS input must be integers",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        test.cancelOrder("user cancelled");
    }

    @Test
    void testInvalidProductCode() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // "item" is not a number
        test.selectProducts("cat", "1");
        Assert.assertEquals("INVALID COMMANDS input must be integers",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        test.cancelOrder("user cancelled");
    }

    @Test
    void testInvalidDoubleQty() {
        Customer test = new Customer();
        test.database_file = "src/main/java/asm2/Product_db.txt";

        // "quantity" is not a whole number
        test.selectProducts("1000", "1.5");
        Assert.assertEquals("INVALID COMMANDS input must be integers",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        test.cancelOrder("user cancelled");
    }

    @Test
    void testCancelOrder(){
        Customer test = new Customer();

        // check that the function completes
        assertEquals("SUCCESS", test.cancelOrder("user cancelled") );
    }

    @Test
    void testCheckCard(){
        Customer test1 = new Customer();

        //check that function can open file
        assertDoesNotThrow(() -> test1.check("Charles", "40691"));


        assertTrue(test1.check("Charles", "40691"));

        assertFalse(test1.check("Cha", "40691"));

        assertFalse(test1.check("Charles", "40"));

        assertTrue(test1.check("charles", "40691"));

    }



    @Test
    void testCashPay() {
        Customer test = new Customer();
        test.selectProducts("3033", "1");
        assertEquals(1.0, test.getTotal());
        Cashier test_pay = new Cashier();
        Double order_total = test.getTotal();
        Double cash_given = 0.0;
        assertEquals("\nNot enough money inserted. Please try again.", test.cash_payment(cash_given));
        Cashier test_change = new Cashier();
        test_change.reset_machine();
        test_change.save_changes();
        test_change.modify_quant("0.50", 1);
        test_change.save_changes();
        cash_given = 3.50;
        assertEquals("\nNot enough change available in the machine. Returning back your cash... Please try again.",
                test.cash_payment(cash_given));
        test_change.modify_quant("2", 2);
        test_change.save_changes();
        assertEquals(4.50, new Cashier().get_total_machine_money());
        cash_given = 3.70; // no twenty cent coin in machine therefore change cannot be given
        assertEquals("\nNot enough change available in the machine. Please enter a different amount of cash.\n>> ",
                test.cash_payment(cash_given));
        cash_given = 3.50;
        test_change.modify_quant("2", -1);
        test_change.save_changes();
        // exact change - 50 cents and two dollar coin is given back
        assertEquals("\nTransaction successful. Thank you for your purchase. Here is your change: \nx1 $2 notes \nx1 0.50 cent coins \n",
                test.cash_payment(cash_given));
    }

    @Test
    public void testCashAmount(){
        Customer test = new Customer();

        assertTrue(test.valid_cash_amount("1.00"));

        assertFalse(test.valid_cash_amount("-3"));

        assertFalse(test.valid_cash_amount("cat"));

    }

    @Test
    public void testFiveRecent(){
        Customer test = new Customer();

        Assert.assertEquals("SUCCESS", test.fiveRecentItems("anonymous"));

    }

    @Test
    public void testTransHistoryCash(){
        Customer test = new Customer();
        test.selectProducts("1000", "1");
        Assert.assertEquals("ITEM ADDED TO CARTYour cart currently contains 1x SpriteTotal 30",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        // ensure enough change available in machine
        new Cashier().modify_quant("0.50", 1);
        new Cashier().modify_quant("1", 1);
        new Cashier().save_changes();
        test.cash_payment(4.50);
        test.generateTransHistory("cash");
        test.cancelOrder("testTransHistoryCash");
        try {
            File f = new File("src/main/java/asm2/CashierR2.txt");
            String s = "";
            Scanner scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            assertTrue(s.contains("Sprite x1, 3.00 paid with cash, 1.50 change returned"));
            scan.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
        // remove change to CashierR2 file
        try {
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/CashierR2.txt", "rw");
            // remove change by deleting the last line
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }

    @Test
    public void testTransHistoryCard(){
        Customer test = new Customer();
        test.selectProducts("1000", "1");
        Assert.assertEquals("ITEM ADDED TO CARTYour cart currently contains 1x SpriteTotal 30",
                outputStreamCaptor.toString().trim().replaceAll("\r", "").replaceAll("\n", "").replaceAll("[^a-zA-Z0-9\\s]", ""));
        test.generateTransHistory("card");
        test.cancelOrder("testTransHistoryCard");
        try {
            File f = new File("src/main/java/asm2/CashierR2.txt");
            String s = "";
            Scanner scan = new Scanner(f);
            while(scan.hasNextLine()){
                s = scan.nextLine();
            }
            assertTrue(s.contains("Sprite x1, 3.00 paid with card, 0.00 change returned"));
            scan.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
        // remove change to CashierR2 file
        try {
            RandomAccessFile file = new RandomAccessFile("src/main/java/asm2/CashierR2.txt", "rw");
            // remove change by deleting the last line
            long f_len = file.length() - 1;
            byte b;
            do {
                f_len -= 1;
                file.seek(f_len);
                b = file.readByte();
            } while(b != 10);
            file.setLength(f_len+1);
            file.close();
        }
        catch (IOException e) {
            System.err.println("Failed to delete last line");
        }
    }
}
