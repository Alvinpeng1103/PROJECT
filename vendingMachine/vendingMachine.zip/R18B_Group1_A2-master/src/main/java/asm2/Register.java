package asm2;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Register {

    public static String[] read(String name) {
        String[] card_info = new String[2];
        try {
            File myObj = new File("src/main/java/asm2/Register.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String[] line = myReader.nextLine().split(", ");
                if (line[0].equals(name)) {
                    card_info[0] = line[1];
                    card_info[1] = line[2];
                }
            }

            myReader.close();
            return card_info;
        } catch (FileNotFoundException e) {
            return null;
        }

    }

    public static boolean check(String x){
        try {
            File myObj = new File("src/main/java/asm2/Register.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String[] line = myReader.nextLine().split(", ");
                if (line[0].equals(x)) {
                    return true;
                }
            }

            myReader.close();
            return false;
        } catch (FileNotFoundException e) {
            return false;
        }
    }

    public static void write(String x, String y, String z){
        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Register.txt");
            myWriter.write(x + ", " + y + ", " + z + "\n");
            myWriter.close();

        } catch (IOException e) {

        }

    }

}
