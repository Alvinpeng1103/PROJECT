package asm2;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.time.ZoneId;
import java.time.ZonedDateTime;


public class Seller {

    private Map<String, String> instructions;


    /**
     * instructions are the command that seller can do
     */
    public Seller() {
        this.instructions = new HashMap<>();
    }






    /**
     * display all instructions
     * the instructions will be printed out
     * format:
     * instruction desc
     */

    public void displayInstructions() {

        System.out.printf("%s %s\n", "Instruction", "Description");

        for (Map.Entry<String, String> entry : instructions.entrySet()) {
            System.out.printf("%s %s\n", entry.getKey(), entry.getValue());
        }
    }

    /**
     * add a new instruction
     *
     * @param instruction String
     * @param desc        String
     */

    public void addInstruction(String instruction, String desc) {

        instructions.put(instruction, desc);
    }


    /**
     * select a certain product, return all information about this product
     *
     * @param code
     * @return
     */
    public String[] selectProduct(String code) {
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code.trim())) {
                    return indiv;
                }
            }

            myReader.close();
            return null;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * display a certain product
     *
     * @param code
     */
    public String displayProduct(String code) {
        if (this.selectProduct(code) != null) {

            Object[] indiv = this.selectProduct(code);
            System.out.printf("%s %s %s %s %s\n", indiv);
            return "SUCCESS";

        } else {
            System.out.println("The product you are looking for does not exist. Try again.");
            return "INVALID";
        }
    }

    /**
     * change the quantity of a certain product
     *
     * @param code
     * @param number
     */

    public void changeQ(String code, String number) {
        List<String> lines = new ArrayList<>();
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code.trim())) {
                    String newStr = indiv[0];
                    for (int i = 1; i < 4; i++) {
                        newStr = newStr + ", " + indiv[i];
                    }

                    newStr = newStr + ", " + number.trim();
                    lines.add(newStr);
                } else {
                    lines.add(data);
                }
            }

            myReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Product_db.txt");
            for (String line : lines) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void changeP(String code, String price) {
        List<String> lines = new ArrayList<>();
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code.trim())) {

                    String newStr = indiv[0] + ", " + indiv[1] + ", " + indiv[2] + ", " + price.trim() + ", " + indiv[4];
                    lines.add(newStr);
                } else {
                    lines.add(data);
                }
            }

            myReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Product_db.txt");
            for (String line : lines) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void changeN(String code, String name) {
        List<String> lines = new ArrayList<>();
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code.trim())) {

                    String newStr = indiv[0] + ", " + indiv[1] + ", " + name.trim() + ", " + indiv[3] + ", " + indiv[4];
                    lines.add(newStr);
                } else {
                    lines.add(data);
                }
            }

            myReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Product_db.txt");
            for (String line : lines) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void changeC(String code, String category) {
        List<String> lines = new ArrayList<>();
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code.trim())) {

                    String newStr = category.trim() + ", " + indiv[1] + ", " + indiv[2] + ", " + indiv[3] + ", " + indiv[4];
                    lines.add(newStr);
                } else {
                    lines.add(data);
                }
            }

            myReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Product_db.txt");
            for (String line : lines) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public void changeCode(String code, String newcode) {
        List<String> lines = new ArrayList<>();
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                //System.out.println(code.trim());
                if (indiv[1].equalsIgnoreCase(code.trim())) {


                    String newStr = indiv[0] + ", " + newcode.trim() + ", " + indiv[2] + ", " + indiv[3] + ", " + indiv[4];
                    lines.add(newStr);
                } else {
                    lines.add(data);
                }
            }

            myReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Product_db.txt");
            for (String line : lines) {
                myWriter.write(line + "\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


    public boolean checkCode(String code) {
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[1].equalsIgnoreCase(code)) {
                    return true;
                }
            }

            myReader.close();
            return false;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean checkName(String name) {
        try {
            File myObj = new File("src/main/java/asm2/Product_db.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] indiv = data.split(", ");

                if (indiv[2].equalsIgnoreCase(name)) {
                    return true;
                }
            }

            myReader.close();
            return false;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }

    }


    /**
     * Seller generates a report of currently available products
     */
    public void generateReport1(){
        // generate report
        try {
            File myObj = new File("src/main/java/asm2/SellerReport1.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists. Updating contents...");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }

        // write to report; replace report contents each time function is called
        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/SellerReport1.txt");

            ArrayList<String> tmp = new ArrayList<>();
            // read available products into a list
            try{
                File myObj = new File("src/main/java/asm2/Product_db.txt");
                Scanner myReader = new Scanner(myObj);
                while(myReader.hasNextLine()){
                    tmp.add(myReader.nextLine());
                }
                myReader.close();
            } catch (FileNotFoundException e){
                System.out.println("An error occurred.");
            }

            // Write available items to file
            for(String item : tmp){
                String[] indiv = (item.split(", "));
                myWriter.write("Item: " + indiv[2] + ", priced at: $" + indiv[3] + ", quantity of: " + indiv[4] + "\n");
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file: SellerReport1.txt");
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
    }


    //seller generates report of sale number of items
    public void generateReport2(){
        int numbersold = 0;
        List<String> itemCodeList = null;
        //go through product_db and write the item codes and names to a list
        try{
            Path productdbpath= Paths.get("src/main/java/asm2/Product_db.txt");
            itemCodeList = new ArrayList<>(Files.readAllLines(productdbpath, StandardCharsets.UTF_8));
            File myObj = new File("src/main/java/asm2/order_history.txt");
            for(int i = 0; i < itemCodeList.size(); i++){
                String[] currentline = itemCodeList.get(i).split(", ");
                Scanner myReader = new Scanner(myObj);
                while(myReader.hasNextLine()){
                    String[] currentline2 = myReader.nextLine().split(", ");
                    if(currentline2[0].equals(currentline[2])){
                        numbersold = numbersold + Integer.parseInt(currentline2[2]);
                    }
                }
                itemCodeList.set(i, "Item Code: " + currentline[1] + " | Item name: " + currentline[2] + " | Units sold: " + Integer.toString(numbersold));
                numbersold = 0;
            }

        }
        catch(IOException e){
            e.printStackTrace();
        }


        try{
            Path reportPath = Paths.get("src/main/java/asm2/SellerReport2.txt");
            Files.write(reportPath, itemCodeList, StandardCharsets.UTF_8);
            System.out.println("\nSuccessfully wrote to the file: SellerReport2.txt");
        }
        catch(IOException e){
            System.out.println("\nReport failed to generate.");
        }

    }




}
