package asm2;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.io.*;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Owner{

    public String addUser(){
        String username, currentrole, newrole, replacedline;
        Scanner scan = new Scanner(System.in);
        System.out.print("\nWhat is the username of the user who's role you would like to alter?\n>> ");
        username = scan.nextLine();
        System.out.print("\nWhat is the current role of this user?\n>> ");
        currentrole = scan.nextLine().toUpperCase();
        List<String> fileContent = null;
        //check logindb if this user exists:
        if(new Login().usernameTaken(username, currentrole)){
            System.out.print("\nWhat role would you like to change the user " + username + " to?\n>> ");
            newrole = scan.nextLine().toUpperCase();
            //updating the users role in logindb:
            try{
                Path filePath = Paths.get("src/main/java/asm2/logindb.txt");
                fileContent = new ArrayList<>(Files.readAllLines(filePath, StandardCharsets.UTF_8));
                for(int i = 0; i< fileContent.size(); i++){
                    String[] currentline = fileContent.get(i).split(", ");
                    if(currentline[0].equals(username) && currentline[2].equals(currentrole)){
                        replacedline = currentline[0] + ", " + currentline[1] + ", " + newrole;
                        fileContent.set(i, replacedline);
                        break;
                    }
                }
            }
            catch(IOException e){
                e.printStackTrace();
            }
            try{
                Path filePath = Paths.get("src/main/java/asm2/logindb.txt");
                Files.write(filePath, fileContent, StandardCharsets.UTF_8);
                System.out.println("\nUser's role successfully changed!");
                return "SUCCESS";
            }
            catch(IOException a){
                return "FAIL";
            }

        }
        else{
            System.out.println("\nThe user you specified does not exist");
            return "FAIL";
        }
    }

    public String removeUser(){
        String username, role;
        boolean usernameexists = false;
        boolean userisacustomer = false;
        Scanner scan = new Scanner(System.in);
        List<String> fileContent = null;
        FileInputStream fis = null;
        System.out.print("\nWhat is the username of the user you would like to remove?\n>> ");
        username = scan.nextLine();
        System.out.print("\nWhat is the associated role to this user?\n>> ");
        role = scan.nextLine().toUpperCase();
        //checking logindb if this user exists. if this user exists, check if they are a customer:
        try{
            fis = new FileInputStream("src/main/java/asm2/logindb.txt");
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
        Scanner sc = new Scanner(fis);
        while(sc.hasNextLine()){
            String[] currentline = sc.nextLine().split(", ");
            if(currentline[0].equals(username) && currentline[2].equals(role)){
                usernameexists = true;
            }
            if(currentline[0].equals(username) && currentline[2].equals("CUSTOMER")){
                userisacustomer = true;
            }
        }

        if(usernameexists == false){
            System.out.println("\nThis user does not exist in the database.");
            return "FAIL";
        }
        if(userisacustomer == true){
            System.out.println("\nCustomers cannot be removed from the database.");
            return "FAIL";
        }
        //now that we have confirmed that the user exists and is not a customer, we remove this user from the db
        try{
            Path filePath = Paths.get("src/main/java/asm2/logindb.txt");
            fileContent = new ArrayList<>(Files.readAllLines(filePath, StandardCharsets.UTF_8));
            for(int i = 0; i < fileContent.size(); i++){
                String[] currentline2 = fileContent.get(i).split(", ");
                if(currentline2[0].equals(username) && currentline2[2].equals(role)){
                    fileContent.remove(i);
                    break;
                }
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        try{
            Path filePath = Paths.get("src/main/java/asm2/logindb.txt");
            Files.write(filePath, fileContent, StandardCharsets.UTF_8);
            System.out.println("\nUser has been successfully removed from the database!");
            return "SUCCESS";
        }
        catch(IOException e){
            return "FAIL";
        }

    }

    public String generateUserInfoReport(){
        //read each line from logindb into indicies of an arraylist
        String replacedline;
        List<String> fileContent = null;
        try{
            Path filePath = Paths.get("src/main/java/asm2/logindb.txt");
            fileContent = new ArrayList<>(Files.readAllLines(filePath, StandardCharsets.UTF_8));
            for(int i = 0; i<fileContent.size(); i++){
                String[] currentline = fileContent.get(i).split(", ");
                replacedline = "Username: " + currentline[0] + " |  Role: " + currentline[2];
                fileContent.set(i, replacedline);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        try{
            Path reportPath = Paths.get("src/main/java/asm2/UserInfoReport.txt");
            Files.write(reportPath, fileContent, StandardCharsets.UTF_8);
            System.out.println("\nSuccessfully wrote to the file: UserInfoReport.txt");
            return "SUCCESS";
        }
        catch(IOException e){
            System.out.println("\nReport failed to generate.");
            return "FAIL";
        }
    }

    public void generateCancelledTxnReport(){
        // generate report
        try {
            File myObj = new File("src/main/java/asm2/CancelledTxnReport.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists. Updating contents...");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }

        // write to report; replace report contents each time function is called
        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/CancelledTxnReport.txt");

            ArrayList<String> tmp = new ArrayList<>();
            // read available products into a list
            try{
                File myObj = new File("src/main/java/asm2/Cancelled_txn.txt");
                Scanner myReader = new Scanner(myObj);
                while(myReader.hasNextLine()){
                    tmp.add(myReader.nextLine());
                }
                myReader.close();
            } catch (FileNotFoundException e){
                System.out.println("An error occurred.");
            }

            // Write available items to file
            for(String item : tmp){
                myWriter.write(item + '\n');
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file: CancelledTxnReport.txt");
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
    }

}
