package asm2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;

public class Cashier {
    private static Map<String, Integer> map = new HashMap<String, Integer>();
    private static Map<String, Integer> quant_changes = new HashMap<String, Integer>();
    public static String[] accepted_notes_and_coins = new String[]
            {"100", "50", "20", "10", "5", "2", "1", "0.50", "0.20", "0.10"};
    private String db_path = "src/main/java/asm2/Machine_change.txt";
    private static String latest_update_time;
    public void help() {
        final Object[][] table = new String[6][];
        table[0] = new String[]{ "| COMMAND ", "DESCRIPTION"};
        table[1] = new String[]{ "| REPORT ", "Display a report of either r1: the latest note/coin quantities in the machine OR r2: all transactions"};
        table[2] = new String[]{ "| <denom> <delta>", " Change a note/coin denomination's quantity by <delta> amount e.g. 'UPD 0.10 -1'"};
        table[3] = new String[]{ "| HELP ", "Displays available cashier commands"};
        table[4] = new String[]{ "| SAVE ", "Commit any note/coin quantity updates and exit the program"};
        table[5] = new String[]{ "| OUT ", "Exit the program without committing any changes"};
        System.out.println("---------------------------------------------------------------------------------------------------------");
        for (final Object[] row : table) {
            System.out.format("%-27s%-50s\n", row);
        } System.out.println("---------------------------------------------------------------------------------------------------------");
        System.out.println("| NOTE:\n| Commands are case-insensitive.");
        System.out.println("| Please write coins in decimal form e.g. 0.10, 0.50, and notes as integer values e.g. 5");
        System.out.println("---------------------------------------------------------------------------------------------------------");
        return;
    }

    public Double get_total_machine_money() {
        Double total = 0.0;
        try {
            File myObj = new File(db_path);
            Scanner myReader = new Scanner(myObj);
            Integer i = 0;
            myReader.nextLine(); // skip report date
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] quant = data.split(", ");
                total += (Double.parseDouble(quant[0]) * Double.parseDouble(quant[1]));
                i++;
            }
            myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
            e.printStackTrace();
        }
        return total;
    }
    public Integer get_quant(String type) {
        return (map.getOrDefault(type, 0));
    }
    public boolean valid_update(String[] cmd_ls) {
        if (cmd_ls.length != 2) {
            System.out.println("\nPlease insert a valid note/coin and quantity");
            return false;
        }
        try {
            Integer.parseInt(cmd_ls[1]);
            // check if valid note/coin argument given
            for (int i = 0; i < Cashier.accepted_notes_and_coins.length; i++) {
                if (Cashier.accepted_notes_and_coins[i].equals(cmd_ls[0])) {
                    return true;
                }
            }
            System.out.println("\nPlease insert a valid note/coin and quantity");
        }
        catch (NumberFormatException ex) {
            System.out.println("\nPlease insert a valid quantity integer");
        }
        return false;
    }
    public void init_map() {
        try {
            File myObj = new File(db_path);
            Scanner myReader = new Scanner(myObj);
            Integer i = 0;
            latest_update_time = myReader.nextLine();
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] quant = data.split(", ");
                map.put(accepted_notes_and_coins[i], Integer.parseInt(quant[1]));
                i++;
            }
            myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
            e.printStackTrace();
        }
    }
    public String modify_quant(String type, Integer quant) {
        if ((map.getOrDefault(type, 0) + quant_changes.getOrDefault(type, 0) + quant) < 0) {
            System.out.println("Please enter a higher amount as there is not enough stock of the note/coin");
            return "INVALID";
        }
        else {
            quant_changes.put(type, quant);
            return "SUCCESS";
        }
    }
    public void reset_machine() { // used in testing
        // revert all quantities to 0 in the database
        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Machine_change.txt", false);
            // deep copy temp_map entries
            for (final String type : accepted_notes_and_coins) {
                map.put(type, 0);
                myWriter.write(type + ", " + map.getOrDefault(type, 0) + "\n");
            }
            myWriter.close();
        }
        catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return;
        }
        System.out.println("\nSuccessfully reset the machine\n");
        return;
    }
    public void empty_changes() { // empty collection of changes
        quant_changes = new HashMap<String, Integer>();
    }
    public void save_changes() { // commit collection of changes to database
        try {
            FileWriter myWriter = new FileWriter("src/main/java/asm2/Machine_change.txt", false);
            // record time of report generation
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            latest_update_time = formatter.format(date);
            myWriter.write(latest_update_time + "\n");
            // deep copy temp_map entries
            for (final String type : accepted_notes_and_coins) {
                map.put(type, map.getOrDefault(type, 0) + quant_changes.getOrDefault(type, 0));
                myWriter.write(type + ", " + map.getOrDefault(type, 0) + "\n");
            }
            quant_changes = new HashMap<String, Integer>(); // empty the map holding basket of changes
            myWriter.close();
        }
        catch (IOException e) {
            e.printStackTrace();
            return;
        }
        System.out.println("\nSuccessfully saved machine cash/note quantity updates\n");
        return;
    }
    public void display_r1() {
        System.out.format("\nReport generated!\nHere is the current quantity of notes and coins in the machine as of %s:\n", latest_update_time);
        Integer quant;
        String stock_warning;
        for (final String type : accepted_notes_and_coins) {
            quant = get_quant(type);
            if (quant < 5) { // notify cashier if restocking is needed
                stock_warning = " (RESTOCKING NEEDED!)";
            }
            else {
                stock_warning = "";
            }
            if (type.equals("0.10")) {
                System.out.format("10c: %d%s\n", quant, stock_warning);
            }
            else if (type.equals("0.20")) {
                System.out.format("20c: %d%s\n", quant, stock_warning);
            }
            else if (type.equals("0.50")) {
                System.out.format("50c: %d%s\n", quant, stock_warning);
            }
            else {
                System.out.format("$%s: %d%s\n", type, quant, stock_warning);
            }
        }
        return;
    }
    public void display_r2() {
        try {
            File myObj = new File("src/main/java/asm2/CashierR2.txt");
            Scanner myReader = new Scanner(myObj);
            System.out.println("\nHere is the latest transaction history:");
            while (myReader.hasNextLine()) {
                System.out.println(myReader.nextLine());
            }
            myReader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("No transactions have been made on this machine.");
            e.printStackTrace();
        }
    }
}
