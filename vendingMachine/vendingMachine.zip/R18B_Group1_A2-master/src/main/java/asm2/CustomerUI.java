package asm2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.util.Scanner;
import java.lang.Thread;
import java.util.HashMap;
import java.util.Map;

public class CustomerUI {
    private static long timerStart;
    private static long timerWait = 120; // allowed idle time is at most 120 seconds
    private static boolean checkTimeOut;
    Scanner scan = new Scanner(System.in);

    private static HashMap<String, String> map;
    public CustomerUI() {
        checkTimeOut = true; // by default check idle time
        map = new HashMap<>();
    }
    public CustomerUI(boolean checkTimeOut) {
        this.checkTimeOut = checkTimeOut; // choose to check or not. For testing will not check
        map = new HashMap<>();
    }
    public void setTimerWait(long timerWait) {
        this.timerWait = timerWait;
    }
    public String getCustomerInput() {
        if (!checkTimeOut) {
            return scan.nextLine();
        }
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            timerStart = System.currentTimeMillis(); // start timer
            while ((System.currentTimeMillis() - timerStart) <= timerWait * 1000
                    && !in.ready()) {
            }
            if (in.ready()) { // user input received before 2 minutes reached
                return in.readLine(); // user input
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        // else user timed out -> return empty string
        return "";
    }
    public void customerTimedOut() {
        System.out.println("\nInactive for more than 2 minutes. Cancelling transaction and returning to default page (list of products)....");
        try {
            TimeUnit.SECONDS.sleep(3);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        new Customer().cancelOrder("timeout"); // Cancel transaction
        new Login().setUsername(null); // Log out
        new Customer().displayProducts(); // Return to default page
        return;
    }
    public void customerCalls(String cmd) {
        while (!"CANCEL".equals(cmd.toUpperCase()) && !"DONE".equals(cmd.toUpperCase())) {
            System.out.print("\nSelect a product by entering its code and the quantity you want. E.g. 1001 3 [Type CANCEL to quit; DONE to checkout; DISP to see menu.]\n>> ");
            cmd = getCustomerInput();
            if (cmd.equals("")) {
                customerTimedOut();
                continue;
            }
            String[] splCmd = cmd.split(" ");

            if (cmd.equalsIgnoreCase("DISP")) {
                new Customer().displayProducts();
            }

            // correct commands for a product selection
            else if (splCmd.length == 2) {
                new Customer().selectProducts(splCmd[0], splCmd[1]);
            }

            // users wants to checkout
            else if (cmd.equalsIgnoreCase("DONE")) {
                System.out.print("\nCHECKOUT COMMENCING\nWould you like to pay with CASH or CARD? You may still CANCEL.\n>> ");
                String payment = getCustomerInput();

                if (payment.equals("")) {
                    customerTimedOut();
                    continue;
                }
                if (payment.equalsIgnoreCase("CANCEL")) {
                    new Customer().cancelOrder("user cancelled");
                    System.out.println("Order was cancelled. Bye!");
                    break;
                } else if (payment.equalsIgnoreCase("CARD")) {

                    String name = new Login().getUsername();

                    String cardRet;


                    if(Register.check(name) == false) {

                        System.out.print("\nPlease enter [cardholder name], e.g. Kate. You may still CANCEL.\n>> ");
                        String cardinp = getCustomerInput();
                        if (cardinp.equals("")) {
                            customerTimedOut();
                            continue;
                        }
                        EraserThread et = new EraserThread("Please enter [card number]: ");
                        Thread mask = new Thread(et);
                        mask.start();
                        String card_num = getCustomerInput();
                        et.stopMasking();
                        if (card_num.equals("")) {
                            customerTimedOut();
                            continue;
                        }
                        cardRet = new App().callCard(cardinp, card_num);

                        while (cardRet.equals("INVALID")) {
                            System.out.print("\nPlease enter [cardholder name], e.g. Kate 12345. You may still CANCEL.\n>> ");
                            cardinp = getCustomerInput();
                            if (cardinp.equals("")) {
                                customerTimedOut();
                                break;
                            }
                            et = new EraserThread("Please enter [card number]: ");
                            mask = new Thread(et);
                            mask.start();
                            card_num = getCustomerInput();
                            et.stopMasking();
                            if (card_num.equals("")) {
                                customerTimedOut();
                                break;
                            }
                            cardRet = new App().callCard(cardinp, card_num);
                        }
                        while(true){
                            String user = new Login().getUsername();
                            if(user.equalsIgnoreCase("anonymous")){
                                break;
                            } else{
                                System.out.print("\nWould you like to save your CARD DETAILS? Y OR N\n>> ");
                                String save = getCustomerInput();
                                if(save.equalsIgnoreCase("Y")){
                                    Register.write(name, cardinp, card_num);
                                    break;
                                }
                                else if(save.equalsIgnoreCase("N")){
                                    break;
                                }else{
                                    continue;
                                }
                            }
                        }

                    }else{
                        String cardinp = Register.read(name)[0];
                        String card_num = Register.read(name)[1];


                        cardRet = new App().callCard(cardinp, card_num);
                    }
                    if (cardRet.equals("CANCEL")) {
                        new Customer().cancelOrder("user cancelled");
                        System.out.println("Order was cancelled. Bye!");
                        System.exit(0);
                    }

                } else if (payment.equalsIgnoreCase("CASH")) {
                    System.out.print("\nPlease enter the amount of cash you would like to input, i.e. 10.50\n>> ");
                    String out;
                    Integer i = 0;
                    String cashAmount = getCustomerInput();
                    if (cashAmount.equals("")) {
                        customerTimedOut();
                        continue;
                    }
                    while (i < 3) {
                        if (new Customer().valid_cash_amount(cashAmount) == false) {
                            continue;
                        }
                        if (cashAmount.equalsIgnoreCase("CANCEL")) {
                            break;
                        }
                        out = new Customer().cash_payment(Double.parseDouble(cashAmount));
                        if (out.contains("\nTransaction successful. Thank you for your purchase.")) {
                            System.out.println(out);
                            new Customer().generateTransHistory("cash");
                            new Customer().checkoutCart();
                            System.exit(0);
                        }
                        System.out.print(out);
                        cashAmount = getCustomerInput();
                        if (cashAmount.equals("")) {
                            customerTimedOut();
                            break;
                        }
                        i++;
                    }
                } else {
                    System.out.print("\nINVALID payment type. Please type CASH or CARD.\n>> ");
                }
            }

            // users wants to cancel
            else if (cmd.equalsIgnoreCase("CANCEL")) {
                new Customer().cancelOrder("user cancelled");
                System.out.println("Order was cancelled. Bye!");
            }

            // unknown command
            else if (splCmd.length == 1 && !"DISP".equals(cmd.toUpperCase()) && !"CANCEL".equals(cmd.toUpperCase()) && !"DONE".equals(cmd.toUpperCase())) {
                System.out.print("\nINCORRECT COMMAND, please read instructions and try again.");
            }

        }

    }

}
