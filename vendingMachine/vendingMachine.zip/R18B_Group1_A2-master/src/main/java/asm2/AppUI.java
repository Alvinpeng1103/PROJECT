package asm2;
import java.util.Scanner;

public class AppUI{
    private static Scanner scan;
    public AppUI() {
        scan = new Scanner(System.in);
    }
    public Scanner getScan() {
        return scan;
    }
    /**
     * Allow seller to modify details of item
     */
    public String modifyWhat(String modifyType){
        Seller seller = new Seller();
        Customer customer = new Customer();

        if (modifyType.trim().equalsIgnoreCase("NAME")){
            //Display products
            customer.displayProducts();

            /*
            ask for product when seller input the code
            if code is valid then the loop is break, else continue the loop
             */
            String code = "";
            while(true){
                System.out.println("\nWhich product's name would you like to change? Enter its CODE.");
                System.out.print(">> ");
                code = scan.nextLine().trim();
                if( ! seller.displayProduct(code).equalsIgnoreCase("INVALID")){
                    break;
                }else{
                    continue;
                }
            }

            /*
            if the name exists in db, ask again; otherwise seller will change the name of the product
             */

            System.out.println("\nWhat is the new name?\n");
            while(true) {
                String newname = "";
                System.out.print(">> ");
                newname = scan.nextLine().trim();

                if(newname.equalsIgnoreCase("q")){
                    return "SUCCESS";
                }
                else if (!code.equalsIgnoreCase("") && !code.equalsIgnoreCase("") && !seller.checkName(newname)) {
                    seller.changeN(code, newname);
                    System.out.println("\nSuccess!");
                    return "SUCCESS";
                }
                else{
                    System.out.println("\nThe name exists. Please rename? or you can type q to exit\n");
                    continue;
                }
            }
        }
        else if (modifyType.trim().equalsIgnoreCase("CODE")){
            //Display products
            customer.displayProducts();


            /*
            ask for product when seller input the code
            if code is valid then the loop is break, else continue the loop
             */
            String code = "";
            while(true){
                System.out.println("\nWhich product's code would you like to change? Enter its CODE.\n");
                System.out.print(">> ");
                code = scan.nextLine().trim();
                if( ! seller.displayProduct(code).equalsIgnoreCase("INVALID")){
                    break;
                }else{
                    continue;
                }
            }

            /*
            check if the input of code is an integer
             */
            String newcode = "";
            System.out.println("\nWhat is the new code?\n");
            while(true){
                System.out.print(">> ");

                newcode = scan.nextLine().trim();

                try{
                    int q = Integer.parseInt(newcode);
                    break;
                }catch(NumberFormatException e){
                    System.out.println("\ninput should be an integer.\n");
                    continue;
                }


            }
            if(! code.equalsIgnoreCase("") && ! code.equalsIgnoreCase("") &&! seller.checkCode(newcode.trim())){
                seller.changeCode(code, newcode.trim());
                System.out.println("\nSuccess!");
                return "SUCCESS";
            }else{
                System.out.println("\nThe code exists.");
                return "SUCCESS";
            }
        }
        else if (modifyType.trim().equalsIgnoreCase("CATEGORY")){

            customer.displayProducts();

            System.out.println("\nWhich product's category would you like to change? Enter its CODE.");
            System.out.print(">> ");
            String code = scan.nextLine().trim();  // user input
            String prod = seller.displayProduct(code);

            while (prod.equals("INVALID")){
                System.out.println("\nWhich product's category would you like to change? Enter its CODE.");
                System.out.print(">> ");
                code = scan.nextLine().trim();  // user input
                prod = seller.displayProduct(code);
            }

            System.out.println("\nWhat is the new category?\n");
            System.out.print(">> ");
            String category = scan.nextLine().trim();  // user input



            if(! customer.check_Category(category)){
                customer.getCategory().add(category);
                seller.changeC(code, category.trim());  // changes the qty
                System.out.println("\nSuccess!");
                return "SUCCESS";

            }else{
                System.out.println("\ncategory would you like to change? Enter its CODE.");
                seller.changeC(code, category.trim());  // changes the qty
                System.out.println("\nSuccess!");
                return "SUCCESS";
            }


        }

        else if (modifyType.trim().equalsIgnoreCase("QUANTITY")){
            customer.displayProducts();
            System.out.println("\nWhich product's quantity would you like to change? Enter its CODE.");
            System.out.println(">> ");
            String code = scan.nextLine().trim();  // user input
            String prod = seller.displayProduct(code);

            while (prod.equals("INVALID")){
                System.out.println("\nWhich product's quantity would you like to change? Enter its CODE.");

                System.out.print(">> ");
                code = scan.nextLine().trim();  // user input
                prod = seller.displayProduct(code);
            }

            System.out.println("\nWhat is the new quantity? (Cannot exceed 15)\n");
            System.out.print(">> ");
            String qty = scan.nextLine().trim();  // user input
            int q = Integer.parseInt(qty);

            while (q < 0 || q > 15){
                System.out.println("\nInvalid quantity! Try again. (Cannot exceed 15)");
                qty = scan.nextLine().trim();  // user input
                q = Integer.parseInt(qty);
            }

            seller.changeQ(code, qty);  // changes the qty
            System.out.println("\nSuccess!");
            return "SUCCESS";
        }
        else if (modifyType.trim().equalsIgnoreCase("PRICE")){

            //Display products
            customer.displayProducts();


            /*
            ask for product when seller input the code
            if code is valid then the loop is break, else continue the loop
             */
            String code = "";
            while(true){
                System.out.println("\nWhich product's price would you like to change? Enter its CODE.");
                System.out.print(">> ");
                code = scan.nextLine().trim();
                if( ! seller.displayProduct(code).equalsIgnoreCase("INVALID")){
                    break;
                }else{
                    continue;
                }
            }

            /*
            check if the input of price is an integer
             */
            String price = "";
            while(true){
                System.out.println("\nWhat is the new price?");
                System.out.print(">> ");
                String qty = scan.nextLine().trim();
                price = qty;
                try{
                    double q = Double.parseDouble(qty);
                    break;
                }catch(NumberFormatException e){
                    System.out.println("\ninput should be an integer.");
                    continue;
                }

            }
            if(! code.equalsIgnoreCase("") && ! price.equalsIgnoreCase("")){
                seller.changeP(code, price);
                System.out.println("\nSuccess!");
                return "SUCCESS";
            }

            return "INVALID";

        }
        else{
            System.out.println("\nIncorrect input. Please type either NAME, CODE, CATEGORY, QUANTITY, PRICE");
            return "INVALID";
        }
    }

    /**
     * Call function to generate report
     */
    public String callReport(String report){
        Seller seller = new Seller();
        Customer customer = new Customer();

        if (report.equalsIgnoreCase("R1")){
            seller.generateReport1();
            return "SUCCESS";
        }
        else if (report.equalsIgnoreCase("R2")){
            seller.generateReport2();
            return "SUCCESS";
        }
        else{
            System.out.println("\nIncorrect input. Please type either R1 or R2");
            return "INVALID";
        }
    }


    /**
     * Call function to generate report
     */
    public String callOwnerReport(String report){
        Owner owner = new Owner();

        if (report.equalsIgnoreCase("R1")){
            owner.generateUserInfoReport();
            return "SUCCESS";
        }
        else if (report.equalsIgnoreCase("R2")){
            owner.generateCancelledTxnReport();
            return "SUCCESS";
        }
        else{
            System.out.println("\nIncorrect input. Please type either R1 or R2");
            return "INVALID";
        }
    }


    public void sellerTransaction() {
        System.out.print("\nWhat would you like to do? \nType MODIFY to update an item; type REPORT to obtain a report. Type OUT to log out.\n>> ");
        String cmdS = scan.nextLine();
        while ( !"OUT".equals( cmdS.toUpperCase()) ){
            if (cmdS.equalsIgnoreCase("MODIFY")){
                System.out.print("\nWhat would you like to modify? Options: NAME, CODE, CATEGORY, QUANTITY, PRICE\n>> ");
                String modifyType = scan.nextLine();
                String modifying = this.modifyWhat(modifyType);
                while(modifying.equals("INVALID")){
                    System.out.print(">> ");
                    modifyType = scan.nextLine();
                    modifying = this.modifyWhat(modifyType);
                }
            }
            else if (cmdS.equalsIgnoreCase("REPORT")){
                System.out.print("\nWhich report would you like to generate? Type R1 or R2\nReport 1: list of the current available items; Report 2: item summary including sales\n>> ");
                String genRep = scan.nextLine();
                String calling = this.callReport(genRep);
                while(calling.equals("INVALID")){
                    genRep = scan.nextLine();
                    calling = this.callReport(genRep);
                }

            }
            else{
                System.out.print("\nIncorrect input. Please type either MODIFY, REPORT, or OUT.\n>> ");
            }
            System.out.print("\nWhat would you like to do? \nType MODIFY to update an item; type REPORT to obtain a report. Type OUT to log out.\n>> ");
            cmdS = scan.nextLine();
        }
        return;
    }

    public void cashierTransaction() {
        new Cashier().init_map();
        System.out.println("\nWelcome Cashier!");
        new Cashier().display_r1();
        System.out.print("\nType REPORT to obtain a report. Type '<denom> <delta>' to change the quantity of a note/coin denomination by <delta> amount e.g. '0.10 -1'.\nType HELP to see all commands; OUT to log out.");
        boolean valid_cmd = false;
        String cmd;
        String[] cmd_ls;
        while (true) {
            System.out.print("\n>> ");
            cmd = scan.nextLine();
            if (cmd.trim().equalsIgnoreCase("SAVE")) {
                break;
            }
            else if (cmd.trim().equalsIgnoreCase("HELP")) {
                new Cashier().help();
                continue;
            }
            else if (cmd.trim().equalsIgnoreCase("REPORT")) {
                System.out.print("\nWhich report would you like to generate? Type R1 or R2\nReport 1: the latest note/coin quantities in the machine; Report2: all transactions\n>> ");
                cmd = scan.nextLine();
                if (cmd.equalsIgnoreCase("R1")) {
                    new Cashier().display_r1();
                }
                else if (cmd.equalsIgnoreCase("R2")) {
                    new Cashier().display_r2();
                }
                else {
                    System.out.println("\nInvalid command. Please enter REPORT again to obtain a report. Else type HELP to see other commands you can perform");
                }
                System.out.print("\nType REPORT to obtain a report. Type '<denom> <delta>' to change the quantity of a note/coin denomination by <delta> amount e.g. '0.10 -1'.\nType HELP to see all commands; OUT to log out.");
                continue;
            }
            else if (cmd.trim().equalsIgnoreCase("OUT")) {
                System.out.println("\nExiting...");
                System.exit(0);
            }
            cmd_ls = cmd.split(" ");
            valid_cmd = new Cashier().valid_update(cmd_ls);
            if (valid_cmd) {
                Integer quant = Integer.parseInt(cmd_ls[1]);
                String res = new Cashier().modify_quant(cmd_ls[0], quant);
                if (res.equals("SUCCESS")) {
                    System.out.print("\nSuccessful operation! Type SAVE to commit changes and exit. Or enter another note/coin and quantity change.");
                }
            }
        }
        new Cashier().save_changes();
        System.out.println("\nSave successful.");
        new Cashier().display_r1();
        return;
    }

    /** MAIN CLASS */
    public static void main(String[] args) {
        System.out.print("\nPlease indicate what type of user you are (type CUSTOMER, CASHIER, SELLER, or OWNER):\n>> ");
        /* Allow user to input a command */
        scan = new Scanner(System.in);
        String input = scan.nextLine();
        /* Get user type */
        String userIs = new App().userType(input);
        /* If user input is invalid, repeat */
        while(userIs.equals("INVALID")) {
            input = scan.nextLine();
            userIs = new App().userType(input);
        }

        /* CUSTOMER ACCESS */
        if(userIs.equals("CUSTOMER")){
            System.out.print("\nWould you like to LOG IN, SIGN UP, or GUEST?\n>> ");
            String cmd = scan.nextLine();
            String access = new App().customerAccess(cmd);

            while(access.equals("INVALID")) {
                System.out.print("\nYour input was invalid. Please type in one of the following: LOG IN, SIGN UP, or GUEST\n>> ");
                cmd = scan.nextLine();
                access = new App().customerAccess(cmd);
            }

            new Customer().displayProducts();   // display products menu

            System.out.println("Last bought items:");
            new Customer().fiveRecentItems(new Login().getUsername()); // display 5 last bought items


            new CustomerUI().customerCalls(cmd);   // call rest of Customer commands

        }

        /* SELLER ACCESS */
        else if (userIs.equals("SELLER")){
            System.out.print("\nWould you like to LOG IN or SIGN UP?\n>> ");

            String cmdS = scan.nextLine();
            String accessS = new App().altAccess(cmdS, "SELLER");

            while(accessS.equals("INVALID")) {
                System.out.print("\nYour input was invalid. Please type in one of the following: LOG IN or SIGN UP\n>> ");
                cmdS = scan.nextLine();
                accessS = new App().altAccess(cmdS, "SELLER");
            }
            new AppUI().sellerTransaction();

        }

        /* CASHIER ACCESS */
        else if (userIs.equals("CASHIER")){
            System.out.print("\nWould you like to LOG IN or SIGN UP?\n>> ");
            String cmd = scan.nextLine();
            String access = new App().altAccess(cmd, "CASHIER");
            while(access.equals("INVALID")) {
                System.out.print("\nYour input was invalid. Please type in one of the following: LOG IN or SIGN UP\n>> ");
                cmd = scan.nextLine();
                access = new App().altAccess(cmd, "CASHIER");
            }
            if(userIs.equals("CASHIER")) {
                new AppUI().cashierTransaction();
                System.exit(0);
            }
        }

        /* OWNER ACCESS */
        else if (userIs.equals("OWNER")){
            System.out.print("\nWould you like to LOG IN or SIGN UP?\n>> ");
            String cmd = scan.nextLine();
            String access = new App().altAccess(cmd, "OWNER");
            while(access.equals("INVALID")) {
                System.out.print("\nYour input was invalid. Please type in one of the following: LOG IN or SIGN UP\n>> ");
                cmd = scan.nextLine();
                access = new App().altAccess(cmd, "OWNER");
            }

            while (!"OUT".equals(cmd.toUpperCase())){
                System.out.print("\nWhat would you like to do?\n> CHANGE a user role \n> DELETE a user\n> REPORT (generates owner report)" +
                        "\n> SELLER (act as a seller; modify item details and access corresponding reports)" +
                        "\n> CASHIER (act as a cashier; modify machines change and access corresponding reports)" +
                        "\n> Or type OUT to log out.\n>> ");
                cmd = scan.nextLine();
                if(cmd.equalsIgnoreCase("CHANGE")){
                    new Owner().addUser();
                }
                else if(cmd.equalsIgnoreCase("DELETE")){
                    new Owner().removeUser();
                }
                else if (cmd.equalsIgnoreCase("REPORT")){
                    System.out.print("\nWhich report would you like to print? R1 for users in the machine and R2 for cancelled transactions.\n>> ");
                    String rep = scan.nextLine();
                    String calling = new AppUI().callOwnerReport(rep);
                    while(calling.equals("INVALID")){
                        rep = scan.nextLine();
                        calling = new AppUI().callReport(rep);
                    }
                }
                else if(cmd.equalsIgnoreCase("SELLER")){
                    new AppUI().sellerTransaction();
                    System.exit(0);
                }
                else if(cmd.equalsIgnoreCase("CASHIER")){
                    new AppUI().cashierTransaction();
                    System.exit(0);
                }
                // unknown command
                else if (!"OUT".equals(cmd.toUpperCase())) {
                    System.out.print("\nINCORRECT COMMAND, please read instructions and try again.");
                }
            }
        }

    }
}
