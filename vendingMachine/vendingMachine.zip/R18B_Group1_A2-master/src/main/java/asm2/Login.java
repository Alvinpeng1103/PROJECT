package asm2;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Login{
    String database_file;
    public static String username;

    public Login(){
        database_file = "src/main/java/asm2/logindb.txt";
    }
    public Login(String db_file){
        database_file = db_file;
    }

    public static void setUsername(String username) {
        Login.username = username;
    }

    public String getUsername(){
        if (username == null){
            username = "anonymous";
        }
        return username;
    }

    public boolean usernameTaken(String username, String type){
        boolean taken = false;
        try {
            File myObj = new File(database_file);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String[] line = myReader.nextLine().split(", ");
                if(line[0].equals(username) && line[2].equals(type)){
                    taken = true;
                }
            }
            myReader.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return taken;
    }
    public boolean passMatching(String pass1, String pass2) {
        if (pass1.equals(pass2)) {
            return true;
        }
        System.out.print("\nPasswords not matching. Re-enter the password again \n>> ");
        return false;
    }
    public String signUpUser(String user, String pass, String type){
        setUsername(user);
        // after username and password has been entered, append them to file
        try{
            FileWriter myWriter = new FileWriter(database_file, true);
            myWriter.write(user + ", " + pass + ", " + type + "\n");
            myWriter.close();
            return "\nSuccessfully signed up. Logging in with your new account...";
        }
        catch(IOException e){
            e.printStackTrace();
            return "\nAn error occurred";
        }
    }

    public boolean logIn(String type){
        //String username = "r";
        String password1 = "random";
        Scanner scan = new Scanner(System.in);
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(database_file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Scanner sc = new Scanner(fis);

        //LOGIN part of the program
        boolean found = false;
        System.out.print("Enter your username: ");
        username = scan.nextLine().trim();
        EraserThread et1 = new EraserThread("Enter Your desired password: ");
        Thread mask1 = new Thread(et1);
        mask1.start();
        password1 = scan.nextLine().trim();
        et1.stopMasking();



        while(sc.hasNextLine()){
            String[] currentline = sc.nextLine().split(", ");
            //checking for existence of username and password combination. Also check correct user type.
            if(username.equals(currentline[0]) && password1.equals(currentline[1]) && type.equals(currentline[2])){
                found = true;
            }
            if(username.equals(currentline[0]) && !password1.equals(currentline[1])){
                System.out.println("This password does not match the username");
            }

        }
        if(found == false){
            System.out.println("\nAccount does not exist");
            return false;
        }
        else{
            setUsername(username);
            System.out.println("\nLogged in!");
            return true;
        }
    }



}
